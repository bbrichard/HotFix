require("IFHttpManager");

defineClass("IFMemberDetailCommonViewController", {
            getBetListData: function() {
            IFHttpManager.getGameBetDetailWithUserName_gamePlatformId_stime_etime_pageNumber_pagesize_SuccessBlock_failBlock(self.memberDetailModel().userName(), self.gamePlatformId(), self.stime(), self.etime(), self.pageNumber(), 15, block("void, id",
                                                                                                                                                                                                                                                  function(response) {
                                                                                                                                                                                                                                                  self.tableView().mj_header().endRefreshing();
                                                                                                                                                                                                                                                  self.tableView().mj_footer().endRefreshing();
                                                                                                                                                                                                                                                  console.log("js endRefreshing")
                                                                                                                                                                                                                                                  var array = response.objectForKey("list");
                                                                                                                                                                                                                                                  self.getModelWithArr(array);
                                                                                                                                                                                                                                                  }), block("void, BaseBusinessSomeError*",
                                                                                                                                                                                                                                                            function(error) {
                                                                                                                                                                                                                                                            self.tableView().mj_header().endRefreshing();
                                                                                                                                                                                                                                                            self.tableView().mj_footer().endRefreshing();
                                                                                                                                                                                                                                                            }));
            }
            },
            {});
