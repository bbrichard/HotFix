defineClass('SwiftJSPatchDemo.DemoTest', {
            
            
            }, {
            staticTestFunction: function(string) {
            console.log('JSPatch staticTestFunction output:!!!!!!!!!!!')
            },
            classTestFunction: function(string) {
            console.log('JSPatch classTestFunction output:!!!!!!!!!!!')
            }
            })
